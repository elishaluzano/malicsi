var myCountdown1 = new Countdown({
	year  	: 2017,  // (optional) The target date's year
	month 	: 11,     // (optional) The target date's month
	day   	: 19,     // (optional) The target date's day
	//width:450, 
	//height:100,  
	rangeHi:"month",
	style:"flip"	// <- no comma on last item!
});