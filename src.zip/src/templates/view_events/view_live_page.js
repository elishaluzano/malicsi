$(document).ready(function(){
	$('.modal').modal();
});