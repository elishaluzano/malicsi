(function() {
    'use strict';

    angular
        .module('app')
        .component('adminPage', {
            template: require('./admin-page.html'),
        });

})();
