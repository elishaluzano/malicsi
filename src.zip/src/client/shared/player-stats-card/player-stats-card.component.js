(function() {
    'use strict';
    angular
        .module('app')
        .component('playerStatsCard',{
            template: require('./player-stats-card.html'),
            controller: playerStatsCardController,
            bindings: {
                user: '<'
            }
            
        });

    function playerStatsCardController(teamService) {
        var vm = this;
        vm.stats = [];

        vm.$onInit = function() {
            teamService.getTeamID(vm.user.user_id)
            .then(
                function(ids){
                    for(let id of ids){
                        teamService.getTeamStats(id)
                        .then
                    }
                }
            }     
        }

    }
})();
